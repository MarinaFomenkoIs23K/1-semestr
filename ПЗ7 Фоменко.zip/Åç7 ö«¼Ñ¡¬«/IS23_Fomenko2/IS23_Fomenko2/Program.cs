﻿using System;
class Program
{
    static void Main()
    {
        string text = "Я скоро поеду на научную конференцию в Курск";
        int index = text.IndexOf("Курск");
        Console.WriteLine("Index of 'Курск': " + index);
        text = text.Remove(text.IndexOf("в Курск"), 7);
        Console.WriteLine("Text after removing 'в Курск': " + text);
        text = text.Replace("научную конференцию", "соревнование");
        Console.WriteLine("Text after replacement: " + text);
        text = text.ToUpper();
        Console.WriteLine("Text in uppercase: " + text);
    }
}