﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите натуральное число K (1 ≤ K ≤ 100000): ");
        int K;
        while (!int.TryParse(Console.ReadLine(), out K) || K < 1 || K > 100000)
        {
            Console.WriteLine("Ошибка: введите корректное натуральное число в диапазоне от 1 до 100000.");
        }

        int palindromeCount = CountPalindromes(K);

        Console.WriteLine($"Количество натуральных палиндромов, не превосходящих {K}: {palindromeCount}");
    }

    static int CountPalindromes(int K)
    {
        int count = 0;

        for (int i = 1; i <= K; i++)
        {
            if (IsPalindrome(i))
            {
                count++;
            }
        }

        return count;
    }

    static bool IsPalindrome(int number)
    {
        string strNumber = number.ToString();
        char[] arr = strNumber.ToCharArray();
        Array.Reverse(arr);
        string reversedStrNumber = new string(arr);

        return strNumber == reversedStrNumber;
    }
}

