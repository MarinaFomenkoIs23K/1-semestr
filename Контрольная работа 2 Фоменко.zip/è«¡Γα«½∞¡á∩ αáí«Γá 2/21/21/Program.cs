﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите вещественное число A: ");
        double A;
        while (!double.TryParse(Console.ReadLine(), out A))
        {
            Console.WriteLine("Ошибка: введите корректное вещественное число.");
        }

        Console.Write("Введите целое число N (> 0): ");
        int N;
        while (!int.TryParse(Console.ReadLine(), out N) || N <= 0)
        {
            Console.WriteLine("Ошибка: введите корректное целое число больше 0.");
        }

        double result = CalculatePower(A, N);

        Console.WriteLine($"{A} в степени {N} равно {result}.");
    }

    static double CalculatePower(double A, int N)
    {
        double result = 1.0;

        for (int i = 0; i < N; i++)
        {
            result *= A;
        }

        return result;
    }
}

