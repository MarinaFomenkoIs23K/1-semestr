﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите целое число n: ");
        int n = int.Parse(Console.ReadLine());

        double sum = 0.0;

        for (int i = 0; i <= n; i++)
        {
            sum += Math.Pow(2, i);
        }

        Console.WriteLine($"Сумма 1 + 2 + 4 + ... + 2^{n} равна {sum}");
    }
}
