﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите положительное число A (длину прямоугольника): ");
        int A = int.Parse(Console.ReadLine());

        Console.Write("Введите положительное число B (ширину прямоугольника): ");
        int B = int.Parse(Console.ReadLine());

        Console.Write("Введите положительное число C (сторону квадрата): ");
        int C = int.Parse(Console.ReadLine());

        if (A <= 0 || B <= 0 || C <= 0)
        {
            Console.WriteLine("Ошибка: все числа должны быть положительными.");
            return;
        }

        int countA = CountSquares(A, C);
        int countB = CountSquares(B, C);

        int totalCount = countA * countB;

        Console.WriteLine($"Максимально возможное количество квадратов со стороной {C}: {totalCount}");
    }

    static int CountSquares(int length, int side)
    {
        int count = 0;

        while (length >= side)
        {
            length -= side;
            count++;
        }

        return count;
    }
}

