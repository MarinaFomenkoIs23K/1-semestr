﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите целое число N (> 1): ");
        int N;

        if (!int.TryParse(Console.ReadLine(), out N) || N <= 1)
        {
            Console.WriteLine("Ошибка: введите целое число больше 1.");
            return;
        }

        bool isFibonacci = IsFibonacci(N);

        Console.WriteLine(isFibonacci ? "TRUE" : "FALSE");
    }

    static bool IsFibonacci(int n)
    {
        int a = 0;
        int b = 1;

        while (b < n)
        {
            int temp = b;
            b = a + b;
            a = temp;
        }

        return b == n;
    }
}

