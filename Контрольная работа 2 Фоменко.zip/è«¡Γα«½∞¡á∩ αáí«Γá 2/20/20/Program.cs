﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите целое число n: ");
        int n;

        while (!int.TryParse(Console.ReadLine(), out n) || n < 0)
        {
            Console.WriteLine("Ошибка: введите корректное неотрицательное целое число.");
        }

        int square = CalculateSquare(n);

        Console.WriteLine($"Квадрат числа {n} равен {square}.");
    }

    static int CalculateSquare(int n)
    {
        int sum = 0;

        for (int i = 0; i < n; i++)
        {
            int term = 2 * i + 1;
            sum += term;
            Console.WriteLine($"Текущее значение суммы после добавления {term}: {sum}");
        }

        return sum;
    }
}

