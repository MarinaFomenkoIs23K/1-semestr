﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите целое положительное число A: ");
        int A = int.Parse(Console.ReadLine());

        Console.Write("Введите целое положительное число B: ");
        int B = int.Parse(Console.ReadLine());
        if (A <= 0 || B <= 0)
        {
            Console.WriteLine("Оба числа должны быть положительными.");
            return;
        }
        int gcd = EuclideanGCD(A, B);

        Console.WriteLine($"Наибольший общий делитель (НОД) чисел {A} и {B} равен {gcd}.");
    }
    static int EuclideanGCD(int a, int b)
    {
        while (b != 0)
        {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }
}
