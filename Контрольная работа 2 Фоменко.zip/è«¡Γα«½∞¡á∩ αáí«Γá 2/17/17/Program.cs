﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите целое число N (> 1), являющееся числом Фибоначчи: ");
        int N = int.Parse(Console.ReadLine());

        if (N <= 1)
        {
            Console.WriteLine("Ошибка: N должно быть больше 1.");
            return;
        }

        int k = FindFibonacciIndex(N);

        if (k != -1)
        {
            Console.WriteLine($"Порядковый номер числа Фибоначчи {N} равен {k}.");
        }
        else
        {
            Console.WriteLine($"Число {N} не является числом Фибоначчи.");
        }
    }

    static int FindFibonacciIndex(int N)
    {
        int a = 0;
        int b = 1;
        int index = 1;

        while (b < N)
        {
            int temp = b;
            b = a + b;
            a = temp;
            index++;
        }

        if (b == N)
        {
            return index;
        }

        return -1;
    }
}

