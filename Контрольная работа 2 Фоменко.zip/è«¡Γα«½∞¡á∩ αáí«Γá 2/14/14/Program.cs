﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите процент P (0 < P < 50): ");
        double P = double.Parse(Console.ReadLine());

        if (P <= 0 || P >= 50)
        {
            Console.WriteLine("Ошибка: значение P должно быть в диапазоне от 0 до 50 (не включая).");
            return;
        }

        double initialDistance = 10.0;
        double totalDistance = 0.0;
        int dayCount = 0;

        double incrementFactor = 1 + (P / 100);

        while (totalDistance <= 200)
        {
            dayCount++;
            totalDistance += initialDistance;
            initialDistance *= incrementFactor;
        }

        Console.WriteLine($"Количество дней K: {dayCount}");
        Console.WriteLine($"Суммарный пробег S: {totalDistance:F2} км");
    }
}

