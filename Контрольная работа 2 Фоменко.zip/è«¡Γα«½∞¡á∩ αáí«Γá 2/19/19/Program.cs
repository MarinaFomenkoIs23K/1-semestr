﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите целое число n: ");
        int n;

        while (!int.TryParse(Console.ReadLine(), out n) || n <= 0)
        {
            Console.WriteLine("Ошибка: введите корректное положительное целое число.");
        }

        double result = CalculateExpression(n);

        Console.WriteLine($"Результат выражения для n = {n}: {result}");
    }

    static double CalculateExpression(int n)
    {
        double sum = 0.0;

        for (int i = 1; i <= n; i++)
        {
            double term = 1 + 0.1 * i;
            if (i % 2 == 0)
            {
                sum -= term;
            }
            else
            {
                sum += term;
            }
        }

        return sum;
    }
}

