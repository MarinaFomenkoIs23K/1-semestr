﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите целое число n: ");
        int n;

        while (!int.TryParse(Console.ReadLine(), out n))
        {
            Console.WriteLine("Ошибка: введите корректное целое число.");
        }

        double sum = CalculateSum(n);

        Console.WriteLine($"Сумма от 1.1 до {1 + 0.1 * n} равна: {sum}");
    }

    static double CalculateSum(int n)
    {
        double sum = 0.0;

        for (int i = 1; i <= n; i++)
        {
            sum += (1 + 0.1 * i);
        }

        return sum;
    }
}

