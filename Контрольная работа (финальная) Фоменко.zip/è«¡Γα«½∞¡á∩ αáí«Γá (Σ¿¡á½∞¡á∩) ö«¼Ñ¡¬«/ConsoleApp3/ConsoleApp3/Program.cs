﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        HashSet<int> possibleNumbers = new HashSet<int>(Enumerable.Range(1, n));
        string question;
        while ((question = Console.ReadLine()) != "HELP")
        {
            var askedNumbers = question.Split(' ').Select(int.Parse).ToList();
            int askedCount = askedNumbers.Count;
            int possibleCount = possibleNumbers.Count;
            int halfCount = possibleCount / 2;
            if (askedCount == halfCount && possibleCount % 2 == 0)
            {
                Console.WriteLine("NO");
                continue;
            }
            bool canAnswerYes = possibleNumbers.Intersect(askedNumbers).Count() < halfCount;
            string answer = canAnswerYes ? "YES" : "NO";
            Console.WriteLine(answer);
            if (answer == "YES")
            {
                possibleNumbers.IntersectWith(askedNumbers);
            }
            else
            {
                possibleNumbers.ExceptWith(askedNumbers);
            }
        }
        Console.WriteLine(string.Join(" ", possibleNumbers.OrderBy(x => x)));
    }
}
