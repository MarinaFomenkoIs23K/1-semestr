﻿using System;
using System.Collections.Generic;
using System.Linq;
class Program
{
    static void Main()
    {
        int numWords = int.Parse(Console.ReadLine());
        Dictionary<string, List<string>> latinToEnglishDict = new Dictionary<string, List<string>>();
        for (int i = 0; i < numWords; i++)
        {
            string line = Console.ReadLine();
            int sep = line.IndexOf('-');
            string englishWord = line.Substring(0, sep - 1);
            string[] latinWords = line.Substring(sep + 2).Split(new[] { ", " }, StringSplitOptions.None);

            foreach (string word in latinWords)
            {
                if (!latinToEnglishDict.ContainsKey(word))
                {
                    latinToEnglishDict[word] = new List<string>();
                }
                latinToEnglishDict[word].Add(englishWord);
            }
        }
        Console.WriteLine(latinToEnglishDict.Count);
        foreach (var latinWord in latinToEnglishDict.Keys.OrderBy(w => w))
        {
            Console.WriteLine($"{latinWord} - {string.Join(", ", latinToEnglishDict[latinWord].OrderBy(e => e))}");
        }
    }
}
