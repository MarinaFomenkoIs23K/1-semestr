﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        int numCountries = int.Parse(Console.ReadLine());
        Dictionary<string, string> citiesCountry = new Dictionary<string, string>();

        for (int i = 0; i < numCountries; i++)
        {
            string[] input = Console.ReadLine().Split();
            string country = input[0];

            for (int j = 1; j < input.Length; j++)
            {
                string city = input[j];
                citiesCountry[city] = country;
            }
        }
        int numTests = int.Parse(Console.ReadLine());
        for (int i = 0; i < numTests; i++)
        {
            string cityQuery = Console.ReadLine();
            Console.WriteLine(citiesCountry[cityQuery]);
        }
    }
}
