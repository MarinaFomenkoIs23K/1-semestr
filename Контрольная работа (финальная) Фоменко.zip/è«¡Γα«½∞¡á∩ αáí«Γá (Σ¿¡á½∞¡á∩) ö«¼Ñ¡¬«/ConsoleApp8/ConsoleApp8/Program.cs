﻿using System;
using System.Collections.Generic;
using System.IO;

class Program
{
    static void Main()
    {
        Dictionary<string, int> votes = new Dictionary<string, int>();
        string line;
        while ((line = Console.ReadLine()) != "")
        {
            var parts = line.Split(' ');
            if (parts.Length != 2 || !int.TryParse(parts[1], out int count))
            {
                Console.WriteLine("EROR");
                continue;
            }
            string candidate = parts[0];
            if (votes.ContainsKey(candidate))
            {
                votes[candidate] += count;
            }
            else
            {
                votes[candidate] = count;
            }
        }
        var sortedCandidates = new List<string>(votes.Keys);
        sortedCandidates.Sort();

        foreach (var candidate in sortedCandidates)
        {
            Console.WriteLine($"{candidate} {votes[candidate]}");
        }
    }
}