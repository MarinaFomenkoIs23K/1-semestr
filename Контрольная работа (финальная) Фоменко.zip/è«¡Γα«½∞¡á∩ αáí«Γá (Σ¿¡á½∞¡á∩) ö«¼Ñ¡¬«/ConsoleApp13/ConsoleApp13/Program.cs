﻿using System;
using System.Collections.Generic;

class Program
{
    static Dictionary<string, int> customers = new Dictionary<string, int>();
    static void CustomerMovement(string name, int amount)
    {
        if (customers.ContainsKey(name))
        {
            customers[name] += amount;
        }
        else
        {
            customers[name] = amount;
        }
    }
    static void Main(string[] args)
    {
        Console.WriteLine("'EXIT' для выхода:");
        while (true)
        {
            string input = Console.ReadLine();
            if (input == null || input.ToUpper() == "EXIT")
            {
                break;
            }
            var data = input.Split();
            var command = data[0].ToUpper();
            switch (command)
            {
                case "DEPOSIT":
                    if (data.Length != 3 || !int.TryParse(data[2], out int depositAmount))
                    {
                        break;
                    }
                    string depositName = data[1];
                    CustomerMovement(depositName, depositAmount);
                    break;
                case "WITHDRAW":
                    if (data.Length != 3 || !int.TryParse(data[2], out int withdrawAmount))
                    {
                        break;
                    }
                    string withdrawName = data[1];
                    CustomerMovement(withdrawName, -withdrawAmount);
                    break;
                case "BALANCE":
                    if (data.Length != 2)
                    {
                        Console.WriteLine("ERROR");
                        break;
                    }
                    string balanceName = data[1];
                    if (customers.TryGetValue(balanceName, out int balance))
                    {
                        Console.WriteLine($"Баланс {balanceName}: {balance}");
                    }
                    else
                    {
                        Console.WriteLine("ERROR");
                    }
                    break;
                case "TRANSFER":
                    if (data.Length != 4 || !int.TryParse(data[3], out int transferAmount))
                    {
                        break;
                    }
                    string transferName1 = data[1];
                    string transferName2 = data[2];
                    CustomerMovement(transferName1, -transferAmount);
                    CustomerMovement(transferName2, transferAmount);
                    break;
                case "INCOME":
                    if (data.Length != 2 || !int.TryParse(data[1], out int percentage))
                    {
                        break;
                    }
                    foreach (var customer in customers.Keys)
                    {
                        if (customers[customer] > 0)
                        {
                            customers[customer] += customers[customer] * percentage / 100;
                        }
                    }
                    break;
                default:
                    Console.WriteLine("EROR Sistem");
                    break;
            }
        }
    }
}
