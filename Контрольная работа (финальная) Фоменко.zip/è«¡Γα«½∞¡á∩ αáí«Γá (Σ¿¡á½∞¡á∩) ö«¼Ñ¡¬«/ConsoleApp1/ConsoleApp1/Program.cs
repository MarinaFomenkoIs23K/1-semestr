﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
namespace ConsoleApp6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string filePath = "C:\\Users\\Student28\\Desktop\\Контрольная работа (финальная) Фоменко\\ConsoleApp1\\ConsoleApp1\\bin\\Debug\\input.txt";
            string text = File.ReadAllText(filePath);
            var words = text.Split(new char[] { ' ', '\n', '\r', '\t', ';', ',', '.', '!', '?', '\'' }, StringSplitOptions.RemoveEmptyEntries);
            HashSet<string> uniqueWords = new HashSet<string>(words.Select(word => word.ToLowerInvariant()));
            Console.WriteLine(uniqueWords.Count);
        }
    }
}