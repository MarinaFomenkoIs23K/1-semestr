﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    internal class Program
    {
        static void Main(string[] args)
        {
            string[] firstLine = Console.ReadLine().Split();
            int N = int.Parse(firstLine[0]);
            int K = int.Parse(firstLine[1]);
            bool[] strikeDays = new bool[N + 1];
            for (int i = 0; i < K; i++)
            {
                string[] partyInfo = Console.ReadLine().Split();
                int a = int.Parse(partyInfo[0]);
                int b = int.Parse(partyInfo[1]);
                for (int day = a; day <= N; day += b)
                {
                    strikeDays[day] = true;
                }
            }
            int strikeCount = 0;
            for (int day = 1; day <= N; day++)
            {
                int dayOfWeek = (day - 1) % 7;
                if (strikeDays[day] && dayOfWeek != 5 && dayOfWeek != 6)
                {
                    strikeCount++;
                }
            }
            Console.WriteLine(strikeCount);
        }
    }
