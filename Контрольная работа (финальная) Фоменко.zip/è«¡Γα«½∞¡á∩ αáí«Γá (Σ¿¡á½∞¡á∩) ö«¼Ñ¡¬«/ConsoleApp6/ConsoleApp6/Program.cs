﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

class Program
{
    static void Main()
    {
        string text = File.ReadAllText("C:\\Users\\Student28\\Desktop\\Контрольная работа (финальная) Фоменко\\ConsoleApp6\\ConsoleApp6\\bin\\Debug\\input.txt");
        var words = Regex.Matches(text, @"\S+").Cast<Match>().Select(m => m.Value).ToList();
        Dictionary<string, int> wordCount = new Dictionary<string, int>();
        List<int> output = new List<int>();
        foreach (var word in words)
        {
            if (wordCount.ContainsKey(word))
            {
                output.Add(wordCount[word]);
                wordCount[word]++;
            }
            else
            {
                output.Add(0);
                wordCount[word] = 1;
            }
        }
        string result = string.Join("", output);
        Console.WriteLine(result);
    }
}
