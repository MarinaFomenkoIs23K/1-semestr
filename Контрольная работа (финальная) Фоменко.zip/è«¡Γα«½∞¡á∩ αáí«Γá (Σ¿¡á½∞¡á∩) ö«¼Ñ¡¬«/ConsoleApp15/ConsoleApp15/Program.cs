﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        HashSet<string> correctAccents = new HashSet<string>();
        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            correctAccents.Add(Console.ReadLine());
        }

        HashSet<string> knownWords = new HashSet<string>();
        foreach (var word in correctAccents)
        {
            knownWords.Add(word.ToLower());
        }

        int errors = 0;
        string[] inputWords = Console.ReadLine().Split();

        foreach (var word in inputWords)
        {
            string lowerWord = word.ToLower();
            if (!knownWords.Contains(lowerWord))
            {
                errors += (CountUpperCaseLetters(word) != 1) ? 1 : 0;
            }
            else
            {
                errors += !correctAccents.Contains(word) ? 1 : 0;
            }
        }

        Console.WriteLine(errors);
    }

    static int CountUpperCaseLetters(string word)
    {
        int count = 0;
        foreach (char c in word)
        {
            if (char.IsUpper(c))
            {
                count++;
            }
        }
        return count;
    }
}
