﻿using System;
using System.Collections.Generic;
class SynonymDictionary
{
    static void Main()
    {
        Dictionary<string, string> synonyms = new Dictionary<string, string>();
        string line;
        while ((line = Console.ReadLine()) != null && line.Trim() != "")
        {
            var words = line.Split(' ');
            if (words.Length == 2)
            {
                synonyms[words[0]] = words[1];
                synonyms[words[1]] = words[0];
            }
        }
        while ((line = Console.ReadLine()) != null)
        {
            string word = line.Trim();
            if (synonyms.ContainsKey(word))
            {
                Console.WriteLine(synonyms[word]);
            }
            else
            {
                Console.WriteLine();
            }
        }
    }
}
