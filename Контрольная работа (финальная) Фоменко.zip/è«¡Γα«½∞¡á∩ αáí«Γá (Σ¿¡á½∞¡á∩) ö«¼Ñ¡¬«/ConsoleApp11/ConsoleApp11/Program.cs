﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

class Program
{
    static void Main()
    {
        string[] lines = File.ReadAllLines("C:\\Users\\Student28\\Desktop\\Контрольная работа (финальная) Фоменко\\ConsoleApp11\\ConsoleApp11\\bin\\Debug\\input.txt");
        Dictionary<string, int> wordCount = new Dictionary<string, int>();
        foreach (string line in lines)
        {
            string[] words = line.Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string word in words)
            {
                if (wordCount.ContainsKey(word))
                {
                    wordCount[word]++;
                }
                else
                {
                    wordCount[word] = 1;
                }
            }
        }
        var sortedWords = wordCount
            .Select(kvp => new { Word = kvp.Key, Count = kvp.Value })
            .OrderByDescending(x => x.Count)
            .ThenBy(x => x.Word);
        foreach (var item in sortedWords)
        {
            Console.WriteLine(item.Word);
        }
    }
}
