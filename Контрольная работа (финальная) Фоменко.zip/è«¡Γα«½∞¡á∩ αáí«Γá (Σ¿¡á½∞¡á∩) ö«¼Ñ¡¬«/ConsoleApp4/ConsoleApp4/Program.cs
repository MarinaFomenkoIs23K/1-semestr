﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace ConsoleApp9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            HashSet<string> allLanguages = new HashSet<string>();
            HashSet<string> commonLanguages = null;

            for (int i = 0; i < N; i++)
            {
                int M_i = int.Parse(Console.ReadLine());
                HashSet<string> currentLanguages = new HashSet<string>();
                for (int j = 0; j < M_i; j++)
                {
                    string language = Console.ReadLine();
                    currentLanguages.Add(language);
                    allLanguages.Add(language);
                }
                if (commonLanguages == null)
                {
                    commonLanguages = new HashSet<string>(currentLanguages);
                }
                else
                {
                    commonLanguages.IntersectWith(currentLanguages);
                }
            }
            Console.WriteLine(commonLanguages.Count);
            foreach (var lang in commonLanguages)
            {
                Console.WriteLine(lang);
            }
            Console.WriteLine(allLanguages.Count);
            foreach (var lang in allLanguages)
            {
                Console.WriteLine(lang);
            }
        }
    }
}
