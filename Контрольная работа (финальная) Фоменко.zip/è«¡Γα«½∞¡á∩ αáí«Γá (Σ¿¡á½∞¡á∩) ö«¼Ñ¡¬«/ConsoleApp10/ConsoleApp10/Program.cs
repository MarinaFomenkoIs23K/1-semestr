﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        int N = int.Parse(Console.ReadLine());
        Dictionary<string, HashSet<char>> filePermissions = new Dictionary<string, HashSet<char>>();
        for (int i = 0; i < N; i++)
        {
            string[] input = Console.ReadLine().Split(' ');
            string fileName = input[0];
            HashSet<char> permissions = new HashSet<char>();
            for (int j = 1; j < input.Length; j++)
            {
                permissions.Add(input[j][0]);
            }

            filePermissions[fileName] = permissions;
        }
        int M = int.Parse(Console.ReadLine());
        for (int i = 0; i < M; i++)
        {
            string[] request = Console.ReadLine().Split(' ');
            char operation = request[0][0];
            string fileName = request[1];
            if (filePermissions.TryGetValue(fileName, out HashSet<char> permissions) && permissions.Contains(operation))
            {
                Console.WriteLine("OK");
            }
            else
            {
                Console.WriteLine("Acces denied");
            }
        }
    }
}
