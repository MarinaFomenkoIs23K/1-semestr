﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            HashSet<int> possibleNumbers = new HashSet<int>(Enumerable.Range(1, n));
            while (true)
            {
                string line = Console.ReadLine();
                if (line == "HELP");
                break;
                var numbers = line.Split(' ').Select(int.Parse).ToList();
                string answer = Console.ReadLine();
                if (answer == "YES")
                {
                    possibleNumbers.IntersectWith(numbers);
                }
                else if (answer == "NO")
                {
                    foreach (var number in numbers)
                    {
                        possibleNumbers.Remove(number);
                    }
                }
            }
            Console.WriteLine(string.Join(" ", possibleNumbers.OrderBy(x => x)));
        }
    }
}
