﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите положительное целое число: ");
        int.TryParse(Console.ReadLine(), out int number);
        number = number > 0 ? number : 0;
        Console.WriteLine($"Делители числа {number}:");
        FindDivisors(number);
    }

    static void FindDivisors(int number)
    {
        for (int i = 1; i <= number; i++)
        {
            if (number % i == 0)
            {
                Console.WriteLine(i);
            }
        }
    }
}

