﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите значение A: ");
        double A = Convert.ToDouble(Console.ReadLine());
        Console.Write("Введите значение w: ");
        double omega = Convert.ToDouble(Console.ReadLine());
        int width = 12;
        int height = 12;
        char[,] graph = new char[height, width];
        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++)
            {
                graph[y, x] = ' ';
            }
        }
        for (double x = 0; x < width; x += 0.2)
        {
            double y = A * Math.Sin(omega * x);
            int graphX = (int)x;
            int graphY = height - 1 - (int)((y + A) * (height - 1) / (2 * A));
            if (graphX >= 0 && graphX < width && graphY >= 0 && graphY < height)
            {
                graph[graphY, graphX] = '*';
            }
        }
        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++)
            {
                Console.Write(graph[y, x]);
            }
            Console.WriteLine();
        }
    }
}
