﻿using System;
class Program
{
    static void Main()
    {
        Console.Write("Введите число (unsigned long): ");
        ulong number = ulong.Parse(Console.ReadLine());
        int zeroCount = CountBinaryZeros(number);
        Console.WriteLine($"Количество нулей в двоичном представлении числа {number}: {zeroCount}");
    }
    static int CountBinaryZeros(ulong number)
    {
        string binaryRepresentation = Convert.ToString((long)number, 2);
        int zeroCount = 0;
        foreach (char bit in binaryRepresentation)
        {
            if (bit == '0')
            {
                zeroCount++;
            }
        }
        return zeroCount;
    }
}
