﻿using System;
class Program
{
    static void Main()
    {
        string lastName = "Фоменко";
        string birthDate = "12.09.2005";
        string birthPlace = "Глушково";
        int age = 19;
        Console.WriteLine($"Фамилия: {lastName}");
        Console.WriteLine($"Дата рождения: {birthDate}");
        Console.WriteLine($"Место рождения: {birthPlace}");
        Console.WriteLine($"Возраст: {age} лет");
    }
}