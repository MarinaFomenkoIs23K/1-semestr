﻿using System;

namespace IS23_Fomenko5
{
    class Program
    {
        static void Main(string[] args)
        {
            char[,] board = new char[8, 8];
            bool isXTurn = true;
            int row = 0;

            do
            {
                for (int col = 0; col < 8; col++)
                {
                    board[row, col] = isXTurn ? 'X' : 'O';
                    Console.Write(board[row, col] + " ");
                }
                Console.WriteLine();
                isXTurn = !isXTurn;
                row++;
            } while (row < 8);

            Console.ReadKey();
        }
    }
}
