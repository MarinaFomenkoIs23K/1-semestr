﻿using System;

namespace IS23_Fomenko2
{
    class Program
    {
        static void Main(string[] args)
        {
            int num, maxNum = int.MinValue, count = 0;
            do
            {
                Console.Write("Введите число (0 для выхода) ");
                if (!int.TryParse(Console.ReadLine(), out num))
                {
                    Console.WriteLine("Неверный ввод. Пожалуйста, введите действительный номер.");
                    continue;
                }
                if (num == 0)
                    break;
                if (num > maxNum)
                {
                    maxNum = num;
                    count = 1;
                }
                else if (num == maxNum)
                {
                    count++;
                }
            } while (true);

            Console.WriteLine($"Максимальное число в последовательности равно {maxNum} и это оказалось {count} раз.");
        }

    }
}
