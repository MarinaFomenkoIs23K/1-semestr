﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Фоменко_Марина
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string name;
            System.Console.WriteLine("Введите ваше имя:");
            name = System.Console.ReadLine();
            System.Console.WriteLine("Приветствую Вас," + name + "!");
        }
    }
}
