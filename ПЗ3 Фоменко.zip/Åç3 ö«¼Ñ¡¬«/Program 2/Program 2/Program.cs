﻿//01_01.cs - Первая программа
using System;
using static System.Console;
class HelloUser
{
    static void Main()
    {
        string name;
        Console.WriteLine("Введите Ваше имя^");
        name = ReadLine();
        Console.WriteLine("Приветствую Вас," + name + "!");
        Console.WriteLine("/infl завершения сеанса нажмите ENTER");
        ReadLine();
    }
}