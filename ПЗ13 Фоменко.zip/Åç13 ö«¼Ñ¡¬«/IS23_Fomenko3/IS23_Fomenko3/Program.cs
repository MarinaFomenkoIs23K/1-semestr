﻿using System;
class Program 
{ 
    static void Main(string[] args) 
    { 
        for (int x = 2; x <= 8; x++) 
        { for (int y = 2; y <= 5; y++) 
            { double z = x * y; 
                Console.WriteLine($"z({x}, {y}) = {z}"); 
            } 
        } 
    } 
}