﻿using System;

namespace Задание_7
{
    class Program
    {
        static void Main()
        {
            Console.Write("Введите номер места: ");
            int n = int.Parse(Console.ReadLine());
            string seatType = "";
            if (n <= 48)
            {
                int r = (n - 1) / 8;
                if (r == 0 || r == 5)
                    seatType = "W";
                else if (r == 1 || r == 4)
                    seatType = "M";
                else
                    seatType = "A";
            }
            else
            {
                int r = (n - 1) / 10;
                if (r == 0 || r == 4)
                    seatType = "W";
                else if (r == 1 || r == 3)
                    seatType = "M";
                else
                    seatType = "A";
            }
            int oppositeSeat = n + (-1) ^ (n % 2 + 1);
            Console.WriteLine($"Номер и тип противоположного сиденья: {oppositeSeat} {seatType}");
        }
    }
}
