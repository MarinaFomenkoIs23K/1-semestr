﻿using System;

namespace Задание_10
{
    class Program
    {
        static bool Good(int num)
        {
            int sum = 0;
            while (num > 0)
            {
                sum += num % 2;
                num /= 2;
            }
            return sum % 2 == 0;
        }

        static void Main()
        {
            int n, x, max = 0, i;
            n = int.Parse(Console.ReadLine());
            string[] input = Console.ReadLine().Split(' ');
            for (i = 0; i < n; i++)
            {
                x = int.Parse(input[i]);
                if (Good(x) && x > max)
                {
                    max = x;
                }
            }
            Console.WriteLine(max);
        }
    }
}
