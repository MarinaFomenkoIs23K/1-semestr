﻿using System;

namespace Задание_6
{
    class Program
    {
        static void Main()
        {
            int n, a, b, c, d, pa, pb, pc, pd, i;
            Console.Write("Введите n: ");
            n = int.Parse(Console.ReadLine());
            a = 0;
            b = 0;
            c = 1;
            d = 0;

            for (i = 1; i <= n; i++)
            {
                pa = a;
                pb = b;
                pc = c;
                pd = d;

                a = pb + pa + pd + pc;
                b = pa + pc + pd;
                c = pa + pb + pd;
                d = pc;
            }

            Console.WriteLine("Общее количество действительных последовательностей: " + (a + b + c + d));
        }
    }
}