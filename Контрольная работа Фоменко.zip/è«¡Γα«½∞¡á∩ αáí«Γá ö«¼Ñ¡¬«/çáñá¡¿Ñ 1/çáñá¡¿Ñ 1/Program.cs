﻿using System;

namespace Задание_1
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] input = Console.ReadLine().Split(' ');
            int t = int.Parse(input[0]);
            int v = int.Parse(input[1]);
            string[] daysInput = Console.ReadLine().Split(' ');
            int[] days = new int[t];
            for (int i = 0; i < t; i++)
            {
                days[i] = int.Parse(daysInput[i]);
            }
            int res = 0;
            for (int i = 0; i < t; i++)
            {
                int dayTrucks = (days[i] + v - 1) / v;
                if (i == 0)
                {
                    dayTrucks = (days[i] + v - 1) / (v / 2);
                }
                res += dayTrucks;
            }
            Console.WriteLine(res);
        }
    }
}
