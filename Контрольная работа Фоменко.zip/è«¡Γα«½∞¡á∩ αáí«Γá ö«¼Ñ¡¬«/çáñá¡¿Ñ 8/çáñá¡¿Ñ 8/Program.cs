﻿using System;
using System.Linq;

namespace Задание_8
{
    class Program
    {
        static void Main()
        {
            int[] input = Console.ReadLine().Split().Select(int.Parse).ToArray();
            int t = input[0];
            int v0 = input[1];
            int[] days = Console.ReadLine().Split().Select(int.Parse).ToArray();
            int res0 = 0;
            int total_v = 0;
            foreach (int v in days)
            {
                res0 += (v + v0 - 1) / v0;
                total_v += v;
            }
            int res1 = (total_v + v0 - 1) / v0;
            Console.WriteLine(res0 - res1);
        }
    }
}
