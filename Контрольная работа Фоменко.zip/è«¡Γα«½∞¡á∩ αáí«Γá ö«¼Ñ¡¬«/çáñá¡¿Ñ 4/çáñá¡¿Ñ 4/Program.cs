﻿using System;

namespace Задание_4
{
    class Program
    {
        static void Main(string[] args)
        {
            int n, i, len, maxLen;
            string s, prevS;

            n = int.Parse(Console.ReadLine());
            maxLen = 0;
            len = 1;
            prevS = "";
            for (i = 0; i < n; i++)
            {
                s = Console.ReadLine();
                if (prevS[0] == s[0])
                {
                    len++;
                }
                else
                {
                    if (len > maxLen)
                    {
                        maxLen = len;
                    }
                    len = 1;
                }
                prevS = s;
            }
            if (len > maxLen)
            {
                maxLen = len;
            }
            Console.WriteLine(maxLen);
        }
    }
}
