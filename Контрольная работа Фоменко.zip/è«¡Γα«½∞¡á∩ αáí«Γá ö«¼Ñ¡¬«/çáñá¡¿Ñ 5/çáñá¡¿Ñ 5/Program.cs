﻿using System;

namespace Задание_5
{
    class Program
    {
        static void Main()
        {
            int N = int.Parse(Console.ReadLine());
            double T = double.Parse(Console.ReadLine());
            double minTemp = double.MaxValue;
            int minDay = 1;
            int count = 0;

            for (int i = 1; i <= N; i++)
            {
                double temp = double.Parse(Console.ReadLine());
                if (temp < minTemp)
                {
                    minTemp = temp;
                    minDay = i;
                }
                if (temp > T)
                {
                    count++;
                }
            }
            Console.WriteLine(minDay);
            Console.WriteLine(count);
        }
    }
}
