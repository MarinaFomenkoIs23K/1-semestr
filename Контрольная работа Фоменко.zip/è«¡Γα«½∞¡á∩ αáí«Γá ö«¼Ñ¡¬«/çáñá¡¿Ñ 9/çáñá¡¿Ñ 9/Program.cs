﻿using System;

namespace Задание_9
{
    class Program
    {
        const int d = 8;

        static long Digit(long x)
        {
            long b = x % d;
            long a = (x % (d * d)) / d;
            long c = x / (d * d);
            a++;
            if (a >= d)
            {
                a = 0;
                if (b % 2 == 0) b++;
                else b--;
            }
            return c * d * d + a * d + b;
        }

        static void Main()
        {
            long a, b, k = 0;
            Console.Write("Введите диапазон (A B): ");
            string[] input = Console.ReadLine().Split(' ');
            a = long.Parse(input[0]);
            b = long.Parse(input[1]);
            for (long x = a; x <= b; x++)
            {
                if (x - Digit(x) < 0) k++;
            }
            Console.WriteLine(k);
        }
    }
}
