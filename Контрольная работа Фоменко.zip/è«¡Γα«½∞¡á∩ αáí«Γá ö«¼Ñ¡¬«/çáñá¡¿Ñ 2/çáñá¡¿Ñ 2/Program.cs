﻿using System;

namespace Задание_2
{
    class Program
    {
        static int Digit(int x)
        {
            int b = x % 8;
            int a = (x % 64) / 8;
            int c = x / 64;
            a++;

            if (a >= 8)
            {
                a = 0;
                if (b % 2 == 0)
                    b++;
                else
                    b--;
            }

            return c * 64 + a * 8 + b;
        }

        static void Main()
        {
            int a, b, x, mx = 0, ox = 0;

            Console.Write("Ввидите (A B): ");
            string[] input = Console.ReadLine().Split(' ');
            a = int.Parse(input[0]);
            b = int.Parse(input[1]);

            for (x = a; x <= b; x++)
            {
                int oh = Math.Abs(x - Digit(x));
                if (oh >= mx)
                {
                    mx = oh;
                    ox = x;
                }
            }

            Console.WriteLine($"максимальная дистания Oh: {mx}, X: {ox}");
        }
    }
}