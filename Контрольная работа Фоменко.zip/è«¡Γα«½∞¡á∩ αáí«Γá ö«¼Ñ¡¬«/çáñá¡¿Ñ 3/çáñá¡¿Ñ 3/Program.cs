﻿using System;

namespace Задание_3
{
    class Program
    {
        static bool Good(int num)
        {
            int sum = 0;
            int k = 0;
            while (num > 0)
            {
                sum += num % 10;
                num /= 10;
                k++;
            }
            return k == 6;
        }
        static void Main()
        {
            int n, m, x, i;
            Console.Write("Введите количество элементов: ");
            n = int.Parse(Console.ReadLine());
            m = 0;
            for (i = 1; i <= n; i++)
            {
                Console.Write("Введите элемент {0}: ", i);
                x = int.Parse(Console.ReadLine());

                if (Good(x) && (x % 8 == 0))
                {
                    m++;
                }
            }
            Console.WriteLine("Количество действительных номеров равно: " + m);
        }
    }
}
