﻿using System;
namespace Negr
{
    class Program
    {
        public void Go()
        {
            Console.WriteLine("Человек идёт");
        }
    }
}
//Класс Program в приведенном коде имеет один метод Go. Метод Go является публичным и не принимает никаких аргументов (void), а также выводит на экран строку "Человек идёт".