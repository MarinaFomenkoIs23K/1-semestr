﻿using ConsoleApp3;
using System;
using System.Xml.Linq;
namespace ConsoleApp3
{
    class Person
    {
        string name;
        int age;

        public Person()
        {
        }
        public Person(string name) : this(name, 18)
        {
        }
        public Person(string name, int age)
        {
            this.name = name;
            this.age = age;
        }
    }
}
class Employee : Person
{
    string company;

    public Employee()
    {
    }
    public Employee(string name, int age, string company) : base(name, age)
    {
        this.company = company;
    }
    public Employee(string name, string company) : base(name)
    {
        this.company = company;
    }
}
//будут вызваны следующие конструкторы в следующем порядке:
//Конструктор базового класса Person с двумя параметрами (string name, int age): base(name, age)
//Конструктор класса Employee с тремя параметрами (string name, int age, string company): this(name, age, company)
//Таким образом сначала будет вызван конструктор базового класса Person с передачей имени "Tom" и возрастом по умолчанию (18), а затем конструктор класса Employee с передачей имени "Tom", возраста (18) и компании "Microsoft".