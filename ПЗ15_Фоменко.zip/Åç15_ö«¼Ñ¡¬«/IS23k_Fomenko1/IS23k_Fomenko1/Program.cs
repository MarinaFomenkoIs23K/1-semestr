﻿using System;

namespace HeloApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Person tom = new Employee();
            Console.ReadKey();
        }
    }
    // Программа не компилируется что класс с классом Person пытался взаимодействовать класс Employee но из за того что класс Person был внутреним это не получалась но сделав класс публичным это решается 
    public class Person
    {

    }
    public class Employee : Person
    {

    }
}
