﻿using System;
namespace F6
{
    class Program
    {
        static void Main(string[] args)
        {
            double a = 6;
            double b = 10;
            double c = (a / 54 * b + 4.89) / (-7.86 - Math.Sqrt(1024) + Math.Pow(a, 2) / (b * 3.9));
            Console.WriteLine($"c получается {Math.Round(c, 2)}");
        }
    }
}