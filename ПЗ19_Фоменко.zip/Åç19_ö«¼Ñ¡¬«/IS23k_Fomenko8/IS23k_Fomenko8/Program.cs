﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace PolygonLength
{
    public class Point
    {
        public double X { get; set; }
        public double Y { get; set; }
        public string Color { get; set; }

        public Point(double x, double y, string color)
        {
            X = x;
            Y = y;
            Color = color;
        }
    }
    public class Polygon
    {
        public List<Point> Points { get; set; }
        public Polygon()
        {
            Points = new List<Point>();
        }
        public void AddPoint(Point point)
        {
            Points.Add(point);
        }
        public double CalculateLength()
        {
            double length = 0.0;
            for (int i = 1; i < Points.Count; i++)
            {
                length += Distance(Points[i - 1], Points[i]);
            }
            return length;
        }
        private double Distance(Point p1, Point p2)
        {
            return Math.Sqrt(Math.Pow(p2.X - p1.X, 2) + Math.Pow(p2.Y - p1.Y, 2));
        }
        public void SortByColor()
        {
            Points = Points.OrderBy(p => p.Color).ToList();
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Polygon polygon = new Polygon();
            Console.WriteLine("Введите количество точек для ломаной линии:");
            int numberOfPoints = int.Parse(Console.ReadLine());
            for (int i = 0; i < numberOfPoints; i++)
            {
                Console.WriteLine($"Введите координаты точки {i + 1} (формат: X Y Color):");
                string[] input = Console.ReadLine().Split(' ');
                if (input.Length == 3 &&
                    double.TryParse(input[0], out double x) &&
                    double.TryParse(input[1], out double y))
                {
                    string color = input[2];
                    polygon.AddPoint(new Point(x, y, color));
                }
                else
                {
                    Console.WriteLine("Неверный формат ввода. Попробуйте еще раз.");
                    i--;
                }
            }
            double length = polygon.CalculateLength();
            Console.WriteLine($"Длина ломаной линии: {length}");
            polygon.SortByColor();
            Console.WriteLine("Точки после сортировки по цвету:");
            foreach (var point in polygon.Points)
            {
                Console.WriteLine($"({point.X}, {point.Y}) - {point.Color}");
            }
            Console.ReadKey();
        }
    }
}
