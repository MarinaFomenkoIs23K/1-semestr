﻿using System;
using System.Collections.Generic;
public struct Point3D
{
    public double X { get; }
    public double Y { get; }
    public double Z { get; }
    public Point3D(double x, double y, double z)
    {
        X = x;
        Y = y;
        Z = z;
    }
    public override string ToString()
    {
        return $"({X}, {Y}, {Z})";
    }
}
class Program
{
    static void Main(string[] args)
    {
        List<Point3D> points = new List<Point3D>();
        Console.WriteLine("Введите количество точек (не более 17):");
        int count = int.Parse(Console.ReadLine());
        for (int i = 0; i < count; i++)
        {
            Console.WriteLine($"Введите координаты точки {i + 1} (x y z):");
            string[] coordinates = Console.ReadLine().Split(' ');
            double x = double.Parse(coordinates[0]);
            double y = double.Parse(coordinates[1]);
            double z = double.Parse(coordinates[2]);
            points.Add(new Point3D(x, y, z));
        }
        Console.WriteLine("Введите приоритет координат:");
        string priority = Console.ReadLine().Replace(" ", "");
        foreach (char c in priority)
        {
            if (c != 'X' && c != 'Y' && c != 'Z')
            {
                Console.WriteLine("Некорректная координата в приоритете. Используйте только X, Y, Z.");
                return;
            }
        }
        SortPoints(points, priority);
    }
    static void SortPoints(List<Point3D> points, string priority)
    {
        points.Sort((p1, p2) =>
        {
            foreach (char c in priority)
            {
                int comparison = 0;
                switch (c)
                {
                    case 'X':
                        comparison = p1.X.CompareTo(p2.X);
                        break;
                    case 'Y':
                        comparison = p1.Y.CompareTo(p2.Y);
                        break;
                    case 'Z':
                        comparison = p1.Z.CompareTo(p2.Z);
                        break;
                }
                if (comparison != 0)
                    return comparison;
            }
            return 0;
        });
        Console.WriteLine("Отсортированные точки:");
        foreach (var point in points)
        {
            Console.WriteLine(point);
        }
    }
}
