﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace PolygonAreaPerimeter
{
    public class RegularPolygon
    {
        public int NumberOfSides { get; }
        public double Area { get; }
        public double SideLength { get; }
        public RegularPolygon(int numberOfSides, double sideLength)
        {
            NumberOfSides = numberOfSides;
            SideLength = sideLength;
            Area = CalculateArea();
        }
        private double CalculateArea()
        {
            return (NumberOfSides * Math.Pow(SideLength, 2)) / (4 * Math.Tan(Math.PI / NumberOfSides));
        }
        public double CalculatePerimeter()
        {
            return NumberOfSides * SideLength;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            List<RegularPolygon> polygons = new List<RegularPolygon>();
            int numberOfPolygons;
            Console.Write("Введите количество правильных многоугольников (не более 25): ");
            while (!int.TryParse(Console.ReadLine(), out numberOfPolygons) || numberOfPolygons < 1 || numberOfPolygons > 25)
            {
                Console.WriteLine("Пожалуйста, введите корректное число от 1 до 25.");
            }
            for (int i = 0; i < numberOfPolygons; i++)
            {
                Console.Write($"Введите количество сторон для многоугольника {i + 1}: ");
                int numberOfSides;
                while (!int.TryParse(Console.ReadLine(), out numberOfSides) || numberOfSides < 3)
                {
                    Console.WriteLine("Количество сторон должно быть не менее 3.");
                }
                Console.Write($"Введите длину стороны для многоугольника {i + 1}: ");
                double sideLength;
                while (!double.TryParse(Console.ReadLine(), out sideLength) || sideLength <= 0)
                {
                    Console.WriteLine("Длина стороны должна быть положительным числом.");
                }
                polygons.Add(new RegularPolygon(numberOfSides, sideLength));
            }
            var sortedByArea = polygons.OrderBy(p => p.Area).ToList();
            var sortedByPerimeter = polygons.OrderBy(p => p.CalculatePerimeter()).ToList();
            Console.WriteLine("\nСортировка по площади:");
            foreach (var polygon in sortedByArea)
            {
                Console.WriteLine($"Многоугольник с {polygon.NumberOfSides} сторонами, Площадь: {polygon.Area:F2}, Периметр: {polygon.CalculatePerimeter():F2}");
            }
            Console.WriteLine("\nСортировка по периметру:");
            foreach (var polygon in sortedByPerimeter)
            {
                Console.WriteLine($"Многоугольник с {polygon.NumberOfSides} сторонами, Площадь: {polygon.Area:F2}, Периметр: {polygon.CalculatePerimeter():F2}");
            }
            double totalArea = polygons.Sum(p => p.Area);
            double totalPerimeter = polygons.Sum(p => p.CalculatePerimeter());
            Console.WriteLine($"\nСуммарная площадь: {totalArea:F2}");
            Console.WriteLine($"Суммарный периметр: {totalPerimeter:F2}");
            Console.ReadKey();
        }
    }
}
