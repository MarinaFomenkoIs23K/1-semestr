﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace ConvexHull
{
    class Program
    {
        public struct Point
        {
            public double X;
            public double Y;
            public Point(double x, double y)
            {
                X = x;
                Y = y;
            }
        }
        public static int Orientation(Point p, Point q, Point r)
        {
            double val = (q.Y - p.Y) * (r.X - q.X) - (q.X - p.X) * (r.Y - q.Y);
            if (val == 0) return 0;
            return (val > 0) ? 1 : 2;
        }
        public static double Distance(Point p1, Point p2)
        {
            return Math.Sqrt((p1.X - p2.X) * (p1.X - p2.X) + (p1.Y - p2.Y) * (p1.Y - p2.Y));
        }
        public static List<Point> ConvexHull(Point[] points)
        {
            int n = points.Length;
            if (n < 3) return new List<Point>();
            Point[] hull = new Point[n];
            int l = 0;
            for (int i = 1; i < n; i++)
                if (points[i].Y < points[l].Y || (points[i].Y == points[l].Y && points[i].X < points[l].X))
                    l = i;

            int p = l, q;
            int hullIndex = 0;

            do
            {
                hull[hullIndex++] = points[p];
                q = (p + 1) % n;

                for (int i = 0; i < n; i++)
                {
                    if (Orientation(points[p], points[i], points[q]) == 2)
                        q = i;
                }
                p = q;
            } while (p != l);
            return hull.Take(hullIndex).ToList();
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Введите количество точек:");
            int n = int.Parse(Console.ReadLine());
            Point[] points = new Point[n];

            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"Введите координаты точки {i + 1} (x y):");
                string[] input = Console.ReadLine().Split();
                double x = double.Parse(input[0]);
                double y = double.Parse(input[1]);
                points[i] = new Point(x, y);
            }
            List<Point> hull = ConvexHull(points);
            Console.WriteLine("Координаты точек, образующих многоугольник:");
            for (int i = 0; i < hull.Count; i++)
            {
                Console.WriteLine($"Точка {i + 1}: ({hull[i].X}, {hull[i].Y})");
            }
            Console.ReadKey();
        }
    }
}
