﻿using System;

namespace NumberConverter
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите число:");
            string stringValue = Console.ReadLine();
            int intValue = int.Parse(stringValue);
            long longValue = (long)intValue;
            float floatValue = (float)intValue;
            Console.WriteLine($"Переменная типа int = {intValue}");
            Console.WriteLine($"Переменная типа long = {longValue}");
            Console.WriteLine($"Переменная типа float = {floatValue}");
        }
    }
}

