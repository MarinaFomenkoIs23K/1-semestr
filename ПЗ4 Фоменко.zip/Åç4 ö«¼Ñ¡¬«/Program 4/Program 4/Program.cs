﻿using System;
namespace Programm_1
{
    class Programm
    {
        static void Main(string[] args)
        {
            float floatValue = 10.32f;
            byte byteValue = (byte)floatValue;
            long longValue = (long)floatValue;
            int intValue = (int)floatValue;
            double doubleValue = floatValue;
            Console.WriteLine($"Переменная типа int = {intValue}");
            Console.WriteLine($"Переменная типа byte = {byteValue}");
            Console.WriteLine($"Переменная типа long = {longValue}");
            Console.WriteLine($"Переменная типа float = {floatValue}");
            Console.WriteLine($"Переменная типа double = {doubleValue}");
        }
    }
}