﻿using System;
using System.IO;

class Program
{
    static void Main(string[] args)
    {
        string[] colors = { "red", "green", "black", "white", "blue" };
        using (StreamWriter writer = new StreamWriter("C:\\Users\\Student28\\Desktop\\ПЗ17_Фоменко\\IS23k_Fomenko2\\colors.txt"))
        {
            foreach (string color in colors)
            {
                writer.WriteLine(color);
            }
        }
    }
}